#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int n;

void build_segment_tree(int from, int to, int current_node, vector<int> &segment_tree, vector<int> &v)
{
    if(from==to)
    {
        segment_tree[current_node]=from; //Note that we save the index here and not the actual value itself.
        return;
    }
    int mid = (from+to)/2;
    build_segment_tree(from, mid, 2*current_node+1, segment_tree, v);
    build_segment_tree(mid+1, to, 2*current_node+2, segment_tree, v);

    int left_index = segment_tree[2*current_node+1];
    int right_index = segment_tree[2*current_node+2];

    //Save the index of the biggest value.
    if(v[left_index] < v[right_index])
    {
        segment_tree[current_node] = right_index;
    }
    else
    {
        segment_tree[current_node] = left_index;
    }
}

int index_of_biggest_element(int permanent_from, int permanent_to, int from, int to, int current_node, vector<int> &segment_tree, vector<int> &v)
{
    //Intervals are completely disjoint
    if(to<permanent_from || from > permanent_to)
    {
        return -1;
    }

    //The current interval we're looking at is completely within the interval that we want.
    if(permanent_from <= from && to <= permanent_to)
    {
        return segment_tree[current_node];
    }

    int mid = (from+to)/2;
    int left_index = index_of_biggest_element(permanent_from, permanent_to, from, mid, 2*current_node+1, segment_tree, v);
    int right_index = index_of_biggest_element(permanent_from, permanent_to, mid+1, to, 2*current_node+2, segment_tree, v);
    if(left_index == -1)
    {
        return right_index;
    }
    else if(right_index == -1)
    {
        return left_index;
    }
    else
    {
        if(v[left_index] < v[right_index])
        {
            return right_index;
        }
        else
        {
            return left_index;
        }
    }
}

int main()
{
    printf("Enter the number of elements.\n");
    scanf("%d", &n);
    vector<int> v(n);
    for(int i=0; i<n; i++)
    {
        printf("Enter the next element.\n");
        scanf("%d", &v[i]);
    }

    vector<int> segment_tree(4*n, -1); //Note this small trick. The actual maximum amount of elements is 2^(ceil(log2(n))+1)-1. But 4*n is always enough.
    build_segment_tree(0, n-1, 0, segment_tree, v);

    printf("Biggest element between index 0 and index 5 is: %d\n", v[index_of_biggest_element(0, 5, 0, n-1, 0, segment_tree, v)]);
    printf("Biggest element between index 3 and index 4 is: %d\n", v[index_of_biggest_element(3, 4, 0, n-1, 0, segment_tree, v)]);
    printf("Biggest element between index 5 and index 7 is: %d\n", v[index_of_biggest_element(5, 7, 0, n-1, 0, segment_tree, v)]);
    printf("Biggest element between index 2 and index 8 is: %d\n", v[index_of_biggest_element(2, 8, 0, n-1, 0, segment_tree, v)]);

    return 0;
}
