#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cmath>
#include <string>

using namespace std;

string s = "";
int n;
void generate_possibilities(int used)
{
    if(used == n)
    {
        cout << s << "\n";
        return;
    }
    for(char ch='a'; ch<='c'; ch++)
    {
        s += ch;
        generate_possibilities(used+1);
        s.erase(s.end()-1);
    }
}

int main()
{
    printf("Enter the number of characters the string should consist of.\n");
    scanf("%d", &n);
    printf("All the possibilities are:\n");
    generate_possibilities(0);

    return 0;
}
