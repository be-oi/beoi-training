#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cmath>
#include <queue>

using namespace std;

int n, m;

int find_root(int node, vector<int> &representative)
{
    if(node == representative[node])
    {
        return node;
    }
    else
    {
        representative[node] = find_root(representative[node], representative);
        return representative[node];
    }

    //One liner:
    //return node == representative[node] ? node : representative[node] = find_root(representative[node], representative);
}


bool in_same_component(int node1, int node2, vector<int> &representative)
{
    return representative[node1] == representative[node2];
}


void join(int node1, int node2, vector<int> &representative, vector<int> &height)
{
    int r1 = find_root(node1, representative);
    int r2 = find_root(node2, representative);
    if(r1 == r2) //If they are in the same component, we can return
    {
        return;
    }
    if(height[r1] <= height[r2])
    {
        if(height[r1] == height[r2])
        {
            height[r2]++;
        }
        representative[r1] = r2;
    }
    else
    {
        representative[r2] = r1;
    }
}


void kruskal(vector< pair<int, pair<int, int> > > &edges, vector< vector< pair<int, int> > > &mst, vector<int> &representative, vector<int> &height)
{
    sort(edges.begin(), edges.end()); //Sort the edges from low weight to high weight
    int edges_taken=0;
    for(int i=0; i<m && edges_taken != n-1; i++)
    {
        int node1 = edges[i].second.first;
        int node2 = edges[i].second.second;
        if(!in_same_component(node1, node2, representative))
        {
            edges_taken++;
            join(node1, node2, representative, height);
            mst[node1].push_back(make_pair(edges[i].first, node2));
            mst[node2].push_back(make_pair(edges[i].first, node1));
        }
    }
}

int minimax(int from, int to, vector< pair<int, pair<int, int> > > &edges, vector< vector< pair<int, int> > > &mst)
{
    int ans = 1000000000;

    vector<int> highest_weight(n, 1000000000);
    highest_weight[from] = 0;
    queue<int> q;
    q.push(from);
    bool reached = false;
    while(!q.empty())
    {
        int current = q.front();
        q.pop();
        for(int i=0; i<mst[current].size(); i++)
        {
            int weight = mst[current][i].first;
            int neighbour = mst[current][i].second;
            if(highest_weight[neighbour] == 1000000000)
            {
                highest_weight[neighbour] = max(highest_weight[current], weight);
                q.push(neighbour);
                if(neighbour == to)
                {
                    reached = true;
                    break;
                }
            }
        }
        if(reached)
        {
            break;
        }
    }
    return highest_weight[to];
}

int main()
{
    scanf("%d %d", &n, &m);
    vector< pair<int, pair<int, int> > > edges(m);
    for(int i=0; i<m; i++)
    {
        int weight, start, finish;
        scanf("%d %d %d", &weight, &start, &finish);

        edges[i] = make_pair(weight, make_pair(start, finish));
    }

    vector< vector< pair<int, int> > > mst(n);
    vector<int> representative(n);
    vector<int> height(n, 0);
    for(int i=0; i<n; i++)
    {
        representative[i] = i;
    }
    kruskal(edges, mst, representative, height);
    printf("The minimax from 3 to 0 is: %d\n", minimax(3, 0, edges, mst));

    return 0;
}
