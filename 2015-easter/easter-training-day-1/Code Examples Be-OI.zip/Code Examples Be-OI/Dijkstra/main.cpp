#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cmath>
#include <queue>

using namespace std;

int inf = 1000000000;
int nb_nodes, nb_edges;
int start_node, finish_node;

//Note the '&' in front of the vectors to call by reference.
int dijkstra(int from, int to, vector< vector< pair<int, int> > > &graph, vector<int> &path_weight, vector<int> &coming_from)
{
    //In C++, priority queue is by default a max-heap (biggest element on top). In Java, it is by default a min-heap.
    priority_queue< pair<int, int>, vector< pair<int, int> >, greater< pair<int, int> > > pq;
    pq.push(make_pair(0, from));
    while(!pq.empty())
    {
        pair<int, int> p = pq.top();
        pq.pop();
        int current_weight = p.first;
        int current_node = p.second;
        if(current_weight > path_weight[current_node]) //Don't process one node multiple times!
        {
            continue;
        }
        path_weight[current_node] = current_weight;
        if(current_node == to)
        {
            break;
        }

        //Extend the current path
        for(int i=0; i<graph[current_node].size(); i++)
        {
            int edge_weight = graph[current_node][i].first;
            int neighbour = graph[current_node][i].second;
            if(current_weight+edge_weight < path_weight[neighbour]) //If we find a better path, update.
            {
                path_weight[neighbour] = current_weight+edge_weight;
                coming_from[neighbour] = current_node;
                pq.push(make_pair(path_weight[neighbour], neighbour));
            }
        }
    }
    return path_weight[to];
}

int main()
{
    printf("Give the number of nodes and number of edges:\n");
    scanf("%d %d", &nb_nodes, &nb_edges);
    vector< vector< pair<int, int> > > graph(nb_nodes);
    for(int i=0; i<nb_edges; i++)
    {
        printf("Enter the weight, the start node and the finish node\n");
        int weight, start, finish;
        scanf("%d %d %d", &weight, &start, &finish);

        //NOTE: make sure you notice if the indices are 1-based or 0-based.
        //Here, we will assume the indices are 0-based.

        //Make indices 0-based
        start--;
        finish--;

        graph[start].push_back(make_pair(weight, finish));
        //If the edges are bidirectional, we also have to add the line: "graph[finish].push_back(make_pair(weight, start));".
        //In this example, we will assume that the edges are unidirectional.
    }

    printf("Enter the start node and the finish node.\n");
    scanf("%d %d", &start_node, &finish_node);
    start_node--;
    finish_node--;
    vector<int> coming_from(nb_nodes, -1);
    vector<int> path_weight(nb_nodes, inf);

    int total_weight = dijkstra(start_node, finish_node, graph, path_weight, coming_from);
    if(total_weight==inf)
    {
        printf("You cannot reach %d from %d!\n", finish_node+1, start_node+1);
    }
    else
    {
        printf("The shortest path from %d to %d has a total weight of %d.\n", start_node+1, finish_node+1, total_weight);
        printf("The path we followed is:\n");
        int current_node=finish_node;
        vector<int> nodes_used;
        nodes_used.push_back(current_node);
        while(current_node != start_node)
        {
            current_node = coming_from[current_node];
            nodes_used.push_back(current_node);
        }

        //The path is now in reversed order, hence we print it from the back to the start.
        for(int i=nodes_used.size()-1; i>=0; i--)
        {
            printf("%d\n", nodes_used[i]+1);
        }
    }

    return 0;
}
